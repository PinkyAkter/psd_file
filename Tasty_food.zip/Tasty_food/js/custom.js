	//preloder

	$(window).on('load', function () {
		$('.preloder').delay(700).fadeOut(700);
	});

	//sticky menu
	$(window).scroll(function () {
		var scrolling = $(this).scrollTop();
		if (scrolling > 100) {
			$('.navbar').addClass('bg');
		} else {
			$('.navbar').removeClass('bg');
		}
	});


	//banner-part
	$('#banner').slick({
		dots: false,
		infinite: false,
		speed: 300,
		slidesToShow: 1,
		slidesToScroll: 1,
		prevArrow: ('<i class="far fa-angle-left prev"></i>'),
		nextArrow: ('<i class="far fa-angle-right next"></i>'),
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3,
					infinite: true,
					dots: true
				}
    },
			{
				breakpoint: 600,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				}
    },
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
	});
	//Back to top

	$('.back').click(function () {
		$('html,body').animate({
			scrollTop: 0
		}, 3000);
	});
